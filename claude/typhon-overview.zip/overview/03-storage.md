# Component 3: Storage Engine

> Persistence layer providing memory-mapped file I/O, page caching, and segment abstractions for all data storage in Typhon.

---

## Overview

The Storage Engine is the foundation for all persistent data in Typhon. It provides a sophisticated page-based abstraction over memory-mapped files, with a clock-sweep cache, async I/O, and multiple segment types for different data patterns.

```mermaid
flowchart TB
    subgraph Consumers["Consumers (Upper Layers)"]
        DATA[Data Engine<br/>ComponentTable, B+Trees]
        DURABLE[Durability<br/>WAL, Recovery]
    end

    subgraph StorageEngine["Storage Engine"]
        MANAGED[ManagedPagedMMF<br/>Page allocation, occupancy]
        PAGED[PagedMMF<br/>Cache, I/O, lifecycle]
    end

    subgraph Segments["Segment Abstractions"]
        LOGICAL[LogicalSegment<br/>Multi-page directories]
        CHUNK[ChunkBasedSegment<br/>Fixed-size chunks]
        VARIABLE[VariableSizedBufferSegment<br/>Variable buffers]
        STRING[StringTableSegment<br/>UTF-8 strings]
    end

    subgraph Access["Access Layer"]
        PAGEACC[PageAccessor<br/>Safe page access]
        CHUNKACC[ChunkAccessor<br/>SIMD-optimized cache]
    end

    DATA --> MANAGED
    DURABLE --> MANAGED
    MANAGED --> PAGED

    LOGICAL --> MANAGED
    CHUNK --> LOGICAL
    VARIABLE --> CHUNK
    STRING --> CHUNK

    PAGEACC --> PAGED
    CHUNKACC --> CHUNK
```

---

## Sub-Components

| # | Name | Purpose | Status |
|---|------|---------|--------|
| **3.1** | [PagedMMF](#31-pagedmmf) | Core memory-mapped file manager with page cache | ✅ Solid |
| **3.2** | [ManagedPagedMMF](#32-managedpagedmmf) | Page allocation and occupancy tracking | ✅ Solid |
| **3.3** | [LogicalSegment](#33-logicalsegment) | Multi-page directory abstraction | ✅ Solid |
| **3.4** | [ChunkBasedSegment](#34-chunkbasedsegment) | Fixed-size chunk allocation | ✅ Solid |
| **3.5** | [PageAccessor](#35-pageaccessor) | Safe page access wrapper | ✅ Solid |
| **3.6** | [ChunkAccessor](#36-chunkaccessor) | SIMD-optimized chunk cache | ✅ Solid |
| **3.7** | [VariableSizedBufferSegment](#37-variablebuffersegment) | Variable-size buffer storage | ✅ Solid |
| **3.8** | [StringTableSegment](#38-stringtablesegment) | UTF-8 string storage | ✅ Solid |

---

## 3.1 PagedMMF

### Purpose

Core memory-mapped file manager handling:
- Page cache with clock-sweep eviction
- Async read/write I/O operations
- Page state machine (Free → Allocating → Shared/Exclusive → Idle)
- Database file lifecycle (create, open, close)

### Page Cache Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Page Cache (Default: 2MB)                        │
├─────────────────────────────────────────────────────────────────────────┤
│  GCHandle-pinned byte array (prevents GC moves)                         │
│  256 pages × 8192 bytes = 2,097,152 bytes                               │
├─────────────────────────────────────────────────────────────────────────┤
│  PageInfo[256] - metadata for each cached page:                         │
│    - State (Free/Allocating/Shared/Exclusive/Idle/IdleAndDirty)         │
│    - FilePageIndex (which file page is cached here)                     │
│    - ClockSweepCounter (0-5, for eviction)                              │
│    - DirtyCounter (pending writes)                                      │
│    - IOReadTask (async load operation)                                  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Clock-Sweep Eviction Algorithm

The cache uses a clock-sweep (second-chance) algorithm:

```csharp
// Simplified algorithm
while (true)
{
    var pageInfo = _pageInfos[_clockHand];

    if (pageInfo.State == PageState.Idle && pageInfo.ClockSweepCounter == 0)
    {
        // Evict this page
        return _clockHand;
    }

    if (pageInfo.ClockSweepCounter > 0)
        pageInfo.ClockSweepCounter--;  // Give it another chance

    _clockHand = (_clockHand + 1) % _cacheSize;
}
```

**Key properties:**
- Counter range: 0-5 (capped to prevent single page dominating)
- Increment on access, decrement on scan
- Page evicted when counter reaches 0

### Page States

```mermaid
stateDiagram-v2
    [*] --> Free
    Free --> Allocating: Request page
    Allocating --> Shared: Load complete (read)
    Allocating --> Exclusive: Load complete (write)
    Shared --> Idle: All readers exit
    Exclusive --> Idle: Writer exits
    Exclusive --> IdleAndDirty: Writer exits (modified)
    Idle --> Shared: New reader
    Idle --> Exclusive: New writer
    IdleAndDirty --> Idle: Write flushed
    Idle --> Free: Evicted
```

### Async I/O

```csharp
// Reads use RandomAccess.ReadAsync
var task = RandomAccess.ReadAsync(_fileHandle, buffer, pageOffset);
pageInfo.IOReadTask = task;

// PageAccessor.EnsureDataReady() blocks until complete
public void EnsureDataReady()
{
    _pageInfo.IOReadTask?.GetAwaiter().GetResult();
}

// Writes batch contiguous pages
foreach (var contiguousGroup in changeSet.GroupContiguous())
{
    await RandomAccess.WriteAsync(_fileHandle, groupBuffer, groupOffset);
}
```

### Code Location

`src/Typhon.Engine/Persistence Layer/PagedMMF.cs` (~1,035 lines)

---

## 3.2 ManagedPagedMMF

### Purpose

Extends PagedMMF with page allocation management:
- Occupancy bitmap tracking (which pages are in use)
- Root file header management
- Higher-level allocation APIs

### File Layout

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Page 0: Root File Header                                                 │
├─────────────────────────────────────────────────────────────────────────┤
│   Offset 0:    RootFileHeader (192 bytes)                               │
│   Offset 192:  Reserved (8000 bytes)                                    │
├─────────────────────────────────────────────────────────────────────────┤
│ Pages 1-3: Occupancy Bitmap Segment                                      │
├─────────────────────────────────────────────────────────────────────────┤
│   Tracks which pages are allocated/free                                 │
│   3-level hierarchy for fast allocation                                 │
├─────────────────────────────────────────────────────────────────────────┤
│ Pages 4+: User Data Pages                                                │
├─────────────────────────────────────────────────────────────────────────┤
│   Segments, chunks, indexes, components...                              │
└─────────────────────────────────────────────────────────────────────────┘
```

### API

```csharp
public class ManagedPagedMMF : PagedMMF
{
    // Allocate a new page
    public int AllocatePage();

    // Free a page
    public void FreePage(int pageIndex);

    // Check if page is allocated
    public bool IsPageAllocated(int pageIndex);

    // Access root header
    public ref RootFileHeader RootHeader { get; }
}
```

### Code Location

`src/Typhon.Engine/Persistence Layer/ManagedPagedMMF.cs` (~378 lines)

---

## 3.3 LogicalSegment

### Purpose

Multi-page abstraction that presents a contiguous index space across multiple physical pages. Uses a directory structure to map logical indices to physical pages.

### Directory Structure

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Root Page (First page of segment)                                        │
├─────────────────────────────────────────────────────────────────────────┤
│   Index Section: 500 entries × 4 bytes = 2000 bytes                     │
│   Data Section:  6000 bytes available                                   │
├─────────────────────────────────────────────────────────────────────────┤
│ Overflow Pages (When > 500 indices needed)                               │
├─────────────────────────────────────────────────────────────────────────┤
│   Index Section: 2000 entries × 4 bytes = 8000 bytes                    │
│   Data Section:  0 bytes (indices only)                                 │
└─────────────────────────────────────────────────────────────────────────┘
```

### Usage Pattern

```csharp
// Create segment
var segment = new LogicalSegment(mmf, segmentIndex);

// Get page by logical index
var pageAccessor = segment.GetPage(logicalIndex);

// Grow segment (add new page)
var newPageIndex = segment.GrowSegment();
```

### Code Location

`src/Typhon.Engine/Persistence Layer/LogicalSegment.cs` (~431 lines)

---

## 3.4 ChunkBasedSegment

### Purpose

Extends LogicalSegment to provide fixed-size chunk allocation within pages. Uses 3-level occupancy bitmaps for fast allocation.

### Chunk Layout

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Page Structure                                                           │
├─────────────────────────────────────────────────────────────────────────┤
│   PageBaseHeader:  64 bytes                                             │
│   PageMetadata:    128 bytes (occupancy bitmaps)                        │
│   PageRawData:     8000 bytes (chunks)                                  │
├─────────────────────────────────────────────────────────────────────────┤
│ Chunk Allocation                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│   Chunks per page = 8000 / chunkSize                                    │
│   Example: 64-byte chunks = 125 chunks per page                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Magic Multiplier Fast Division

Computing `chunkIndex / chunksPerPage` is expensive (~20-80 cycles). The segment uses a magic multiplier trick:

```csharp
// Precomputed at segment creation
_divMagic = (0x1_0000_0000UL + (uint)_otherChunkCount - 1) / (uint)_otherChunkCount;

// Fast division (~3-4 cycles)
public (int pageIndex, int slotIndex) GetChunkLocation(int chunkIndex)
{
    var adjusted = chunkIndex - _rootChunkCount;
    var pageIndex = (int)((adjusted * _divMagic) >> 32);
    var slotIndex = adjusted - (pageIndex * _otherChunkCount);
    return (pageIndex + 1, slotIndex);
}
```

### Code Location

`src/Typhon.Engine/Persistence Layer/ChunkBasedSegment.cs` (~150 lines)

---

## 3.5 PageAccessor

### Purpose

Safe wrapper for page access that manages state transitions and provides typed access to page sections.

### Page Sections

```csharp
public ref struct PageAccessor
{
    // Header section (64 bytes)
    public ref PageBaseHeader Header { get; }

    // Metadata section (128 bytes)
    public Span<byte> Metadata { get; }

    // Raw data section (8000 bytes)
    public Span<byte> RawData { get; }

    // Ensure async load is complete
    public void EnsureDataReady();
}
```

### Usage

```csharp
// Read access
using (var accessor = mmf.GetPageShared(pageIndex))
{
    accessor.EnsureDataReady();
    var data = accessor.RawData;
    // Read data...
}

// Write access
using (var accessor = mmf.GetPageExclusive(pageIndex))
{
    accessor.EnsureDataReady();
    var data = accessor.RawData;
    // Modify data...
}
```

### Code Location

`src/Typhon.Engine/Persistence Layer/PageAccessor.cs` (~282 lines)

---

## 3.6 ChunkAccessor

### Purpose

SIMD-optimized chunk access with 16-slot cache. This is a **critical hot path** component with three-tier optimization:

1. **MRU Check** - Most recently used slot (single comparison)
2. **SIMD Search** - Vector256 parallel search of all 16 slots
3. **LRU Eviction** - Replace least recently used on miss

### Cache Structure

```csharp
[InlineArray(16)]
public struct SlotArray
{
    private SlotData _element0;  // 16 bytes per slot
}

public struct SlotData
{
    public int ChunkIndex;      // Which chunk is cached
    public int Offset;          // Offset within page
    public int PageCacheIndex;  // Which cache page
    public int LastAccess;      // MRU counter
}
```

### SIMD Search Implementation

```csharp
// Two parallel searches (8 slots each)
var searchVec = Vector256.Create(chunkIndex);

var slots0 = Vector256.LoadUnsafe(ref chunkIndices[0]);
var slots1 = Vector256.LoadUnsafe(ref chunkIndices[8]);

var match0 = Vector256.Equals(slots0, searchVec);
var match1 = Vector256.Equals(slots1, searchVec);

var mask0 = match0.ExtractMostSignificantBits();
var mask1 = match1.ExtractMostSignificantBits();

if (mask0 != 0) return BitOperations.TrailingZeroCount(mask0);
if (mask1 != 0) return BitOperations.TrailingZeroCount(mask1) + 8;
```

### Performance

| Operation | Cycles (Approx) |
|-----------|-----------------|
| MRU hit | 3-4 |
| SIMD hit | 10-15 |
| Cache miss + load | 100+ (depends on page state) |

### Code Location

`src/Typhon.Engine/Persistence Layer/ChunkAccessor.cs` (~743 lines)

---

## 3.7 VariableSizedBufferSegment

### Purpose

Stores variable-size buffers of uniform element types. Used for multi-value index entries and other variable-length data.

### Features

- Linked chunk chains for buffers exceeding chunk size
- Reference counting for shared buffers
- Lazy cleanup of freed chunks
- Automatic chunk deallocation

### Code Location

`src/Typhon.Engine/Persistence Layer/VariableSizedBufferSegment.cs` (~388 lines)

---

## 3.8 StringTableSegment

### Purpose

UTF-8 string storage across chunks using linked chunks for long strings.

### Features

- Store/load/delete operations
- Linked chunks for strings exceeding chunk size
- Efficient encoding/decoding

### Code Location

`src/Typhon.Engine/Persistence Layer/StringTableSegment.cs` (~111 lines)

---

## Page Structure

All pages share a common structure:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Page (8192 bytes total)                           │
├─────────────────────────────────────────────────────────────────────────┤
│ Offset 0-63:     PageBaseHeader (64 bytes)                              │
│   - Flags, BlockType, FormatRevision                                    │
│   - ChangeRevision (incremented on each write)                          │
│   - PageIndex (for validation)                                          │
├─────────────────────────────────────────────────────────────────────────┤
│ Offset 64-191:   PageMetadata (128 bytes)                               │
│   - Occupancy bitmaps for chunk-based segments                          │
│   - Segment-specific metadata                                           │
├─────────────────────────────────────────────────────────────────────────┤
│ Offset 192-8191: PageRawData (8000 bytes)                               │
│   - Actual payload data                                                 │
│   - Segment type determines interpretation                              │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Configuration

### PagedMMFOptions

```csharp
public class PagedMMFOptions
{
    // Cache size (default: 256 pages = 2MB)
    public int PageCacheSize { get; set; } = 256;

    // Enable async I/O (default: true)
    public bool UseAsyncIO { get; set; } = true;

    // File creation options
    public FileMode FileMode { get; set; } = FileMode.OpenOrCreate;
}
```

---

## Key Optimizations

| Optimization | Description | Impact |
|--------------|-------------|--------|
| **GCHandle Pinning** | Page cache never moves in memory | Enables safe pointer arithmetic |
| **Clock-Sweep** | Adaptive cache eviction | Prevents thrashing, respects access patterns |
| **Magic Multiplier** | Replace division with multiply+shift | 3-4 cycles vs 20-80 cycles |
| **SIMD Search** | Vector256 parallel slot comparison | 16 comparisons in ~2 instructions |
| **Contiguous Writes** | Batch adjacent dirty pages | Reduces I/O operations |
| **Lazy Dirty Tracking** | Defer writes until eviction | Reduces unnecessary I/O |
| **Sequential Allocation** | Prefer adjacent memory pages | Better cache locality |
| **Inline Arrays** | Zero-allocation cache slots | No heap pressure in hot path |

---

## Testing

Tests located in `test/Typhon.Engine.Tests/`:

| Test Class | Focus |
|------------|-------|
| `PagedMMFTests` | Cache eviction, I/O operations, state transitions |
| `ManagedPagedMMFTests` | Page allocation, occupancy tracking |
| `LogicalSegmentTests` | Directory structure, overflow handling |
| `ChunkBasedSegmentTests` | Chunk allocation, bitmap operations |

---

## Current State

The Storage Engine is **mature and well-optimized**. Key areas:

| Aspect | Status | Notes |
|--------|--------|-------|
| Core I/O | ✅ Solid | Memory-mapped files, async read/write |
| Page Cache | ✅ Solid | Clock-sweep, configurable size |
| Segments | ✅ Solid | Logical, chunk-based, variable, string |
| Concurrency | ✅ Solid | Reader-writer locks per page |
| Performance | ✅ Solid | SIMD, magic multiplier, lazy dirty |
| Error Handling | ⚠️ Minimal | Basic corruption detection only |
| Recovery | ⚠️ Missing | No WAL or crash recovery yet |

### Future Improvements

1. **WAL Integration** - Add write-ahead logging for durability
2. **Checkpointing** - Periodic consistent snapshots
3. **Corruption Detection** - Checksums, magic numbers
4. **Metrics** - Page hit/miss ratios, I/O latencies

---

## Design Decisions

| Question | Decision | Rationale |
|----------|----------|-----------|
| **Page size** | 8192 bytes | Balance between overhead and granularity; matches common OS page sizes |
| **Cache algorithm** | Clock-sweep | Simple, effective, low overhead; adapts to access patterns |
| **Counter cap** | 5 | Prevents single hot page from dominating cache |
| **SIMD in hot path** | Yes | ChunkAccessor is called millions of times; worth the complexity |
| **Async I/O** | Yes | Non-blocking reads improve throughput under load |
| **Pinned memory** | Yes | Required for safe pointer arithmetic in unsafe code |
