# Component 9: Resource Management

> Memory budgets, page cache limits, and fail-fast behavior on resource exhaustion.

---

## Overview

The Resource Management component controls Typhon's resource consumption, ensuring predictable behavior under load and providing graceful degradation or fail-fast when limits are reached.

```mermaid
flowchart TB
    subgraph Typhon["Typhon Engine"]
        STORAGE[Storage Engine]
        DATA[Data Engine]
        TX[Transactions]
    end

    subgraph ResourceMgmt["Resource Management"]
        BUDGET[Memory Budgets<br/>Limits per subsystem]
        TRACKER[Usage Tracker<br/>Real-time monitoring]
        POLICY[Exhaustion Policy<br/>Fail-fast or degrade]
    end

    subgraph Resources["Managed Resources"]
        CACHE[Page Cache<br/>Configurable size]
        TXPOOL[Transaction Pool<br/>Max active txns]
        CHUNKS[Chunk Allocators<br/>Segment memory]
    end

    STORAGE --> CACHE
    DATA --> CHUNKS
    TX --> TXPOOL

    CACHE --> BUDGET
    TXPOOL --> BUDGET
    CHUNKS --> BUDGET
    BUDGET --> TRACKER
    TRACKER --> POLICY
```

---

## Status: ⚠️ Partial

Some resource limits exist (page cache size, transaction pool) but there's no unified resource management or exhaustion handling.

---

## Sub-Components

| # | Name | Purpose | Status |
|---|------|---------|--------|
| **9.1** | [Memory Budgets](#91-memory-budgets) | Per-subsystem memory limits | ⚠️ Partial |
| **9.2** | [Usage Tracking](#92-usage-tracking) | Real-time resource monitoring | 🆕 New |
| **9.3** | [Exhaustion Policy](#93-exhaustion-policy) | Behavior when limits reached | 🆕 New |

---

## 9.1 Memory Budgets

### Purpose

Define and enforce memory limits for each subsystem.

### Current Implementation

Some limits exist but are scattered:

```csharp
// Page cache size (configurable)
public class PagedMMFOptions
{
    public int PageCacheSize { get; set; } = 256;  // pages (2MB default)
}

// Transaction pool (hardcoded)
private const int MaxPooledTransactions = 16;
```

### Target Design

Unified resource configuration:

```csharp
public class ResourceOptions
{
    // Page cache
    public int PageCachePages { get; set; } = 256;         // 2MB default
    public int MaxPageCachePages { get; set; } = 16384;    // 128MB max

    // Transactions
    public int MaxActiveTransactions { get; set; } = 1000;
    public int TransactionPoolSize { get; set; } = 16;

    // Segments
    public long MaxSegmentMemoryBytes { get; set; } = 1L << 30;  // 1GB

    // Indexes
    public int MaxIndexNodes { get; set; } = 1_000_000;

    // Overall
    public long TotalMemoryBudgetBytes { get; set; } = 4L << 30;  // 4GB
}
```

### Budget Hierarchy

```
Total Budget (4GB)
├── Page Cache (2GB)
│   └── Eviction at 90% capacity
├── Transaction State (256MB)
│   ├── Active transactions (128MB)
│   └── Revision chains (128MB)
├── Indexes (1GB)
│   ├── B+Tree nodes (768MB)
│   └── Variable buffers (256MB)
└── Working Memory (768MB)
    ├── Query execution (512MB)
    └── Misc allocations (256MB)
```

---

## 9.2 Usage Tracking

### Purpose

Monitor resource consumption in real-time for metrics and policy decisions.

### Design Sketch

```csharp
public interface IResourceTracker
{
    // Current usage
    long GetUsedBytes(ResourceCategory category);
    long GetBudgetBytes(ResourceCategory category);
    double GetUtilization(ResourceCategory category);

    // Allocation tracking
    void TrackAllocation(ResourceCategory category, long bytes);
    void TrackDeallocation(ResourceCategory category, long bytes);

    // Snapshots for metrics
    ResourceSnapshot GetSnapshot();
}

public enum ResourceCategory
{
    PageCache,
    TransactionState,
    IndexNodes,
    VariableBuffers,
    QueryExecution,
    Miscellaneous
}

public record ResourceSnapshot
{
    public DateTime Timestamp { get; init; }
    public IReadOnlyDictionary<ResourceCategory, ResourceUsage> Usage { get; init; }
}

public record ResourceUsage
{
    public long UsedBytes { get; init; }
    public long BudgetBytes { get; init; }
    public long PeakBytes { get; init; }
}
```

---

## 9.3 Exhaustion Policy

### Purpose

Define behavior when resource limits are reached.

### Policy Options

| Policy | Behavior | Use Case |
|--------|----------|----------|
| **FailFast** | Throw exception immediately | Critical systems, early failure detection |
| **Wait** | Block until resources available | Batch processing, can tolerate delays |
| **Evict** | Force eviction of least-used resources | Cache-like behavior |
| **Degrade** | Continue with reduced functionality | Best-effort systems |

### Design Sketch

```csharp
public interface IExhaustionPolicy
{
    // Called when allocation would exceed budget
    ExhaustionResult OnExhaustion(
        ResourceCategory category,
        long requestedBytes,
        long availableBytes);
}

public enum ExhaustionResult
{
    Allow,      // Proceed despite budget (soft limit)
    Deny,       // Reject allocation (hard limit)
    Wait,       // Wait for resources to free
    Evict       // Force eviction and retry
}

public class FailFastPolicy : IExhaustionPolicy
{
    public ExhaustionResult OnExhaustion(...)
    {
        throw new ResourceExhaustedException(category, requestedBytes);
    }
}
```

### Per-Category Policies

```csharp
public class ResourcePolicyOptions
{
    // Page cache: evict old pages
    public ExhaustionPolicy PageCachePolicy { get; set; } = ExhaustionPolicy.Evict;

    // Transactions: fail-fast to prevent overload
    public ExhaustionPolicy TransactionPolicy { get; set; } = ExhaustionPolicy.FailFast;

    // Indexes: wait for cleanup
    public ExhaustionPolicy IndexPolicy { get; set; } = ExhaustionPolicy.Wait;
}
```

---

## Integration Points

### Page Cache Eviction

```csharp
// When cache is full
if (_usedPages >= _maxPages)
{
    switch (_policy.OnExhaustion(ResourceCategory.PageCache, pageSize, 0))
    {
        case ExhaustionResult.Evict:
            EvictOldestPage();
            break;
        case ExhaustionResult.Wait:
            WaitForPageRelease();
            break;
        case ExhaustionResult.Deny:
            throw new ResourceExhaustedException("Page cache full");
    }
}
```

### Transaction Limits

```csharp
public Transaction CreateTransaction()
{
    if (_activeCount >= _maxTransactions)
    {
        _resourceTracker.OnExhaustion(ResourceCategory.TransactionState, ...);
        // Policy determines behavior
    }

    return AllocateTransaction();
}
```

---

## Metrics Integration

Resource metrics exposed via Observability:

```csharp
// Gauges
typhon.resources.page_cache.used_bytes
typhon.resources.page_cache.budget_bytes
typhon.resources.page_cache.utilization

typhon.resources.transactions.active
typhon.resources.transactions.max

// Counters
typhon.resources.exhaustion_events
typhon.resources.evictions
```

---

## Code Locations

| Component | Location | Status |
|-----------|----------|--------|
| Resource Registry | `src/Typhon.Engine/Misc/Resource Registry/` | ⚠️ Partial |
| Memory Allocator | `src/Typhon.Engine/Misc/MemoryAllocator/` | ⚠️ Partial |
| Page Cache Options | `src/Typhon.Engine/Persistence Layer/PagedMMFOptions.cs` | ✅ Exists |

---

## Design Decisions

| Question | Decision | Rationale |
|----------|----------|-----------|
| **Granularity** | Per-category budgets | Different resources need different policies |
| **Default policy** | FailFast for transactions, Evict for cache | Safety first, graceful for cache |
| **Tracking overhead** | Atomic counters | Minimal impact on hot path |
| **Configuration** | At startup | Avoid runtime complexity |

---

## Open Questions

1. **Dynamic limits?** - Should budgets be adjustable at runtime?

2. **Pressure signals?** - Should we expose "memory pressure" events for adaptive behavior?

3. **Per-component budgets?** - Should different component types have different memory limits?
