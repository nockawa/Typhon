# Component 8: Observability

> OpenTelemetry traces/metrics, health checks, and diagnostics for monitoring Typhon.

---

## Overview

The Observability component provides visibility into Typhon's internal operations through standardized telemetry (OpenTelemetry), health checks, and diagnostic APIs.

```mermaid
flowchart TB
    subgraph Typhon["Typhon Engine"]
        DATA[Data Engine]
        STORAGE[Storage Engine]
        CONCURRENCY[Concurrency]
    end

    subgraph Observability["Observability"]
        METRICS[Metrics<br/>Counters, Histograms]
        TRACES[Traces<br/>Distributed tracing]
        LOGS[Structured Logs<br/>Serilog]
        HEALTH[Health Checks]
    end

    subgraph Sinks["Telemetry Sinks"]
        OTEL[OpenTelemetry<br/>Collector]
        GRAFANA[Grafana LGTM<br/>Production]
        SEQ[Seq<br/>Development]
    end

    DATA --> METRICS
    STORAGE --> METRICS
    CONCURRENCY --> METRICS
    DATA --> TRACES
    STORAGE --> TRACES

    METRICS --> OTEL
    TRACES --> OTEL
    LOGS --> SEQ
    LOGS --> OTEL
    OTEL --> GRAFANA
    HEALTH --> GRAFANA
```

---

## Status: ⚠️ Partial

Some telemetry infrastructure exists but is currently coupled to `#if TELEMETRY` compile-time flags. Migration to runtime configuration is in progress.

---

## Sub-Components

| # | Name | Purpose | Status |
|---|------|---------|--------|
| **8.1** | [Metrics](#81-metrics) | Counters, histograms, gauges | ⚠️ Partial |
| **8.2** | [Traces](#82-traces) | Distributed tracing spans | 🆕 New |
| **8.3** | [Structured Logging](#83-structured-logging) | Serilog-based logs | ✅ Exists |
| **8.4** | [Health Checks](#84-health-checks) | System health monitoring | 🆕 New |
| **8.5** | [Telemetry Configuration](#85-telemetry-configuration) | Runtime enable/disable | 🔧 In Progress |

---

## 8.1 Metrics

### Purpose

Collect quantitative measurements for monitoring and alerting.

### Key Metrics

| Category | Metric | Type | Description |
|----------|--------|------|-------------|
| **Transactions** | `typhon.tx.count` | Counter | Total transactions |
| | `typhon.tx.duration_ms` | Histogram | Transaction duration |
| | `typhon.tx.conflicts` | Counter | Conflict count |
| **Page Cache** | `typhon.cache.hits` | Counter | Cache hit count |
| | `typhon.cache.misses` | Counter | Cache miss count |
| | `typhon.cache.evictions` | Counter | Pages evicted |
| | `typhon.cache.dirty_pages` | Gauge | Current dirty pages |
| **I/O** | `typhon.io.reads` | Counter | Page reads |
| | `typhon.io.writes` | Counter | Page writes |
| | `typhon.io.read_bytes` | Counter | Bytes read |
| | `typhon.io.write_bytes` | Counter | Bytes written |
| **Locks** | `typhon.lock.contention_ns` | Histogram | Lock wait time |
| | `typhon.lock.acquisitions` | Counter | Lock acquisitions |
| **Indexes** | `typhon.index.lookups` | Counter | B+Tree lookups |
| | `typhon.index.inserts` | Counter | B+Tree insertions |

### OpenTelemetry Integration

```csharp
// Metrics registration
var meter = new Meter("Typhon.Engine", "1.0.0");

var txCounter = meter.CreateCounter<long>("typhon.tx.count");
var txDuration = meter.CreateHistogram<double>("typhon.tx.duration_ms");
var cacheHits = meter.CreateCounter<long>("typhon.cache.hits");
var dirtyPages = meter.CreateObservableGauge("typhon.cache.dirty_pages",
    () => _pageCache.DirtyPageCount);
```

---

## 8.2 Traces

### Purpose

Track request flow through the engine for debugging and performance analysis.

### Trace Spans

| Span | Attributes | Description |
|------|------------|-------------|
| `typhon.transaction` | tsn, duration | Transaction lifecycle |
| `typhon.read` | entity_id, component | Component read |
| `typhon.write` | entity_id, component | Component write |
| `typhon.commit` | changes_count | Transaction commit |
| `typhon.index.lookup` | index, key | B+Tree lookup |
| `typhon.page.load` | page_id | Page load from disk |

### Example Trace

```
Transaction (TSN: 12345, 2.3ms)
├── Read Player (entity: 1001, 0.1ms)
├── Read Inventory (entity: 1001, 0.1ms)
│   └── Page Load (page: 42, 0.08ms)
├── Update Player (entity: 1001, 0.05ms)
├── Index Update (AccountId, 0.02ms)
└── Commit (changes: 1, 0.15ms)
```

---

## 8.3 Structured Logging

### Purpose

Emit structured log events for debugging and auditing.

### Current Implementation

Typhon uses Serilog with Microsoft.Extensions.Logging abstractions:

```csharp
// Logger setup
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .Enrich.FromLogContext()
    .Enrich.With<CurrentFrameEnricher>()
    .WriteTo.Seq("http://localhost:5341")
    .CreateLogger();

// Usage
_logger.LogDebug("Transaction {TSN} committed with {ChangeCount} changes",
    transaction.TSN, changeCount);
```

### Log Levels

| Level | Use Case |
|-------|----------|
| **Verbose** | Internal details (page access, lock acquisition) |
| **Debug** | Development debugging |
| **Information** | Transaction lifecycle, significant events |
| **Warning** | Conflicts, retries, degraded performance |
| **Error** | Failures requiring attention |
| **Fatal** | Unrecoverable errors |

---

## 8.4 Health Checks

### Purpose

Expose system health for container orchestration and monitoring.

### Health Check Types

| Check | Description | Degraded Threshold |
|-------|-------------|-------------------|
| **Database** | Can read/write | Any failure |
| **Page Cache** | Hit ratio | < 80% |
| **Memory** | Available memory | < 10% free |
| **Disk** | Disk space | < 5% free |
| **Transactions** | Active tx count | > 1000 |

### Design Sketch

```csharp
public interface IHealthCheck
{
    string Name { get; }
    Task<HealthCheckResult> CheckAsync(CancellationToken token = default);
}

public enum HealthStatus
{
    Healthy,
    Degraded,
    Unhealthy
}

public record HealthCheckResult
{
    public HealthStatus Status { get; init; }
    public string Description { get; init; }
    public IReadOnlyDictionary<string, object> Data { get; init; }
}
```

---

## 8.5 Telemetry Configuration

### Purpose

Runtime control of telemetry collection without recompilation.

### Current State

Telemetry is currently compile-time:

```csharp
#if TELEMETRY
    RecordContention(waitDuration);
#endif
```

### Target State

Runtime configuration using JIT-friendly static readonly:

```csharp
public static class TelemetryConfig
{
    // Set once at startup, JIT can optimize away disabled paths
    public static readonly bool MetricsEnabled;
    public static readonly bool TracingEnabled;
    public static readonly bool VerboseLoggingEnabled;
}

// Usage (JIT-optimized when disabled)
if (TelemetryConfig.MetricsEnabled)
{
    _txCounter.Add(1);
}
```

### Configuration Options

```csharp
public class TelemetryOptions
{
    // Master switch
    public bool Enabled { get; set; } = false;

    // Granular control
    public bool MetricsEnabled { get; set; } = true;
    public bool TracingEnabled { get; set; } = true;
    public bool VerboseLoggingEnabled { get; set; } = false;

    // Sampling
    public double TraceSamplingRatio { get; set; } = 1.0;

    // Export
    public string OtlpEndpoint { get; set; } = "http://localhost:4317";
}
```

---

## Telemetry Sinks

### Development: Seq + Aspire Dashboard

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Development Stack                                                        │
├─────────────────────────────────────────────────────────────────────────┤
│   Logs ────────────────────────────────► Seq (localhost:5341)           │
│   Metrics/Traces ──────────────────────► Aspire Dashboard               │
└─────────────────────────────────────────────────────────────────────────┘
```

### Production: Grafana LGTM

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Production Stack (Grafana LGTM)                                          │
├─────────────────────────────────────────────────────────────────────────┤
│   Logs ────► OpenTelemetry Collector ────► Loki ────┐                   │
│   Metrics ──► OpenTelemetry Collector ────► Mimir ──┼──► Grafana        │
│   Traces ───► OpenTelemetry Collector ────► Tempo ──┘                   │
└─────────────────────────────────────────────────────────────────────────┘
```

See [Dashboard Research](../research/Dashboard.md) for full comparison.

---

## Code Locations

| Component | Location | Status |
|-----------|----------|--------|
| Telemetry Config | `src/Typhon.Engine/Telemetry/` | 🔧 In Progress |
| AccessControl Telemetry | `src/Typhon.Engine/Misc/AccessControl/AccessControl.Telemetry.cs` | ✅ Exists |
| Logging | `src/Typhon.Engine/Hosting/` | ✅ Exists |

---

## Design Decisions

| Question | Decision | Rationale |
|----------|----------|-----------|
| **Telemetry framework** | OpenTelemetry | Industry standard, vendor-neutral |
| **Runtime vs compile-time** | Runtime with `static readonly` | Single binary, JIT optimization |
| **Production sink** | Grafana LGTM | Full-stack solution, good visualization |
| **Development sink** | Seq + Aspire | Rich local debugging |
| **Sampling** | Configurable | Balance detail vs overhead |

---

## Open Questions

1. **Custom Grafana dashboards?** - Should we ship pre-built dashboards?

2. **Alerting rules?** - Should we provide default alert configurations?

3. **Profiling integration?** - Should we support dotnet-trace/dotnet-counters?
