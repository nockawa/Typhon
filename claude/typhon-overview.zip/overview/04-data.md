# Component 4: Data Engine

> Core database logic providing schema management, component tables, B+Tree indexes, MVCC transactions, and revision chains.

---

## Overview

The Data Engine is the heart of Typhon, implementing the ECS-inspired data model with full ACID transaction support. It builds on the Storage Engine to provide typed component storage, automatic indexing, and multi-version concurrency control.

```mermaid
flowchart TB
    subgraph Application
        APP[Application Code]
    end

    subgraph DataEngine["Data Engine"]
        DBE[DatabaseEngine<br/>Orchestration]
        TX[Transaction<br/>MVCC operations]
        CHAIN[TransactionChain<br/>Active tx management]
    end

    subgraph PerComponent["Per-Component Storage"]
        CT[ComponentTable<br/>Schema + segments]
        COMP[ComponentSegment<br/>Component data]
        REV[CompRevTableSegment<br/>Revision chains]
    end

    subgraph Indexes["B+Tree Indexes"]
        PK[PrimaryKeyIndex<br/>EntityID → RevChain]
        L16[L16BTree<br/>16-bit keys]
        L32[L32BTree<br/>32-bit keys]
        L64[L64BTree<br/>64-bit keys]
        S64[String64BTree<br/>64-byte strings]
    end

    subgraph Schema["Schema System"]
        DEF[DBComponentDefinition]
        DEFS[DatabaseDefinitions]
    end

    APP --> DBE
    DBE --> TX
    DBE --> CHAIN
    TX --> CT
    CT --> COMP
    CT --> REV
    CT --> PK
    CT --> L16
    CT --> L32
    CT --> L64
    CT --> S64
    DBE --> DEFS
    CT --> DEF
```

---

## Sub-Components

| # | Name | Purpose | Status |
|---|------|---------|--------|
| **4.1** | [DatabaseEngine](#41-databaseengine) | Top-level orchestration, component registration | ✅ Solid |
| **4.2** | [Transaction](#42-transaction) | MVCC operations, snapshot isolation | ✅ Solid |
| **4.3** | [TransactionChain](#43-transactionchain) | Active transaction tracking, pooling | ✅ Solid |
| **4.4** | [ComponentTable](#44-componenttable) | Per-component storage and indexes | ✅ Solid |
| **4.5** | [Revision Chains](#45-revision-chains) | MVCC history management | ✅ Solid |
| **4.6** | [B+Tree Indexes](#46-btree-indexes) | Fast key-value lookups | ✅ Solid |
| **4.7** | [Schema System](#47-schema-system) | Component/field/index metadata | ✅ Solid |

---

## 4.1 DatabaseEngine

### Purpose

Top-level API for all database operations:
- Creates and manages transactions via TransactionChain
- Maintains ComponentTables (one per registered component type)
- Generates unique primary keys for entities
- Manages system schema persistence

### API

```csharp
public class DatabaseEngine : IDisposable
{
    // Component registration
    public void RegisterComponent<T>() where T : unmanaged;

    // Transaction management
    public Transaction CreateTransaction();

    // Primary key generation
    public long GeneratePrimaryKey();

    // Access internals
    public DatabaseDefinitions DBD { get; }
    public ManagedPagedMMF MMF { get; }
    public TransactionChain TransactionChain { get; }
}
```

### Component Registration Flow

```mermaid
sequenceDiagram
    participant App
    participant DBE as DatabaseEngine
    participant DEFS as DatabaseDefinitions
    participant CT as ComponentTable

    App->>DBE: RegisterComponent<PlayerComponent>()
    DBE->>DEFS: GetOrCreate definition
    DEFS-->>DBE: DBComponentDefinition
    DBE->>CT: new ComponentTable(definition)
    CT->>CT: Create segments (Component, RevTable, Indexes)
    DBE->>DBE: Store in _componentTables dictionary
```

### Code Location

`src/Typhon.Engine/Database Engine/DatabaseEngine.cs`

---

## 4.2 Transaction

### Purpose

Implements MVCC snapshot isolation with optimistic concurrency control:
- Each transaction sees a consistent snapshot from its creation time
- Changes are cached locally until commit
- Conflict detection at commit time
- Supports read-your-own-writes

### Transaction Sequence Number (TSN)

Every transaction has a unique 48-bit TSN:

```csharp
public readonly struct TSN
{
    // 48-bit value, incremented atomically per transaction
    // At 1M transactions/second, lasts ~8,900 years
    private readonly long _value;
}
```

### Operations

```csharp
public class Transaction : IDisposable
{
    // Create entities (1-3 components)
    public long CreateEntity<T>(ref T component);
    public long CreateEntity<T1, T2>(ref T1 c1, ref T2 c2);
    public long CreateEntity<T1, T2, T3>(ref T1 c1, ref T2 c2, ref T3 c3);

    // Attach additional component to existing entity
    public void CreateComponent<T>(long entityId, ref T component);

    // Read
    public bool ReadEntity<T>(long entityId, out T component);

    // Update
    public void UpdateEntity<T>(long entityId, T component);

    // Delete
    public bool DeleteEntity<T>(long entityId);

    // Index access
    public IIndex<TKey> GetIndex<TComponent, TKey>(string fieldName);

    // Commit or rollback
    public bool Commit();
    public void Rollback();
}
```

### Snapshot Isolation

```mermaid
sequenceDiagram
    participant T1 as Transaction 1 (TSN=100)
    participant T2 as Transaction 2 (TSN=101)
    participant Rev as Revision Chain

    Note over T1,Rev: T1 starts, sees data at TSN ≤ 100

    T2->>Rev: Create revision (TSN=101, IsolationFlag=1)
    Note over Rev: Revision invisible to T1

    T1->>Rev: Read entity
    Rev-->>T1: Returns revision with TSN ≤ 100

    T2->>T2: Commit (clears IsolationFlag)
    Note over Rev: Now visible to new transactions

    T1->>Rev: Read entity again
    Rev-->>T1: Still returns TSN ≤ 100 (snapshot)
```

### Conflict Detection

At commit time, the transaction checks if any component it modified was also modified by another committed transaction:

```csharp
// Conflict detection
if (revInfo.LastCommitRevisionIndex >= curRevisionIndex)
{
    // Another transaction committed since we read
    // Options:
    // 1. Default: Last write wins (copy our data forward)
    // 2. Custom: Call ConcurrencyConflictHandler
}
```

### Code Location

`src/Typhon.Engine/Database Engine/Transaction.cs` (~1,540 lines)

---

## 4.3 TransactionChain

### Purpose

Doubly-linked list managing all active transactions:
- Tracks Head (newest) and Tail (oldest) transactions
- Maintains MinTSN for garbage collection
- Implements transaction pooling (max 16)

### Structure

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        TransactionChain                                  │
├─────────────────────────────────────────────────────────────────────────┤
│   Head ──────────────────────────────────────────────────────── Tail    │
│    │                                                              │      │
│    ▼                                                              ▼      │
│  [T100] ◄──► [T99] ◄──► [T98] ◄──► [T97] ◄──► [T96] ◄──► [T95]         │
│  newest                                                      oldest     │
├─────────────────────────────────────────────────────────────────────────┤
│   MinTSN = 95 (for GC: revisions with TSN < 95 can be cleaned)         │
│   Pool: [T94, T93, T92, ...] (up to 16 reusable transactions)          │
└─────────────────────────────────────────────────────────────────────────┘
```

### Garbage Collection

When the oldest transaction completes:

```csharp
// Transaction disposal triggers cleanup
public void Dispose()
{
    if (this == _chain.Tail)
    {
        // I'm the oldest - trigger GC
        CleanUpUnusedEntries();
    }
    _chain.Remove(this);
}
```

### Code Location

`src/Typhon.Engine/Database Engine/TransactionChain.cs`

---

## 4.4 ComponentTable

### Purpose

Per-component-type storage managing:
- Component data segments
- Revision chain segments
- Primary key and secondary indexes

### Structure

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    ComponentTable<PlayerComponent>                       │
├─────────────────────────────────────────────────────────────────────────┤
│   DBComponentDefinition ──► Schema metadata                              │
├─────────────────────────────────────────────────────────────────────────┤
│   ComponentSegment (ChunkBasedSegment)                                   │
│     └── Stores actual PlayerComponent structs                           │
├─────────────────────────────────────────────────────────────────────────┤
│   CompRevTableSegment (ChunkBasedSegment)                               │
│     └── Stores revision chains (MVCC history)                           │
├─────────────────────────────────────────────────────────────────────────┤
│   PrimaryKeyIndex (L64BTree)                                            │
│     └── Maps EntityID (long) → RevisionChain first chunk                │
├─────────────────────────────────────────────────────────────────────────┤
│   Secondary Indexes                                                      │
│     ├── L32BTree for int PlayerId field                                 │
│     ├── String64BTree for String64 Name field                           │
│     └── ...                                                              │
└─────────────────────────────────────────────────────────────────────────┘
```

### Storage Sizing

```csharp
// Per-component overhead calculation
ComponentStorageSize = sizeof(T);                    // Raw component
ComponentOverhead = 4 * MultipleIndicesCount;        // Element IDs for multi-value indexes
ComponentTotalSize = ComponentStorageSize + ComponentOverhead;
```

### Code Location

`src/Typhon.Engine/Database Engine/ComponentTable.cs`

---

## 4.5 Revision Chains

### Purpose

Stores MVCC history for each entity-component pair as a circular buffer of revisions.

### Structure

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      CompRevStorageHeader (58 bytes)                     │
├─────────────────────────────────────────────────────────────────────────┤
│   NextChunkId       : Linked list to next chunk                         │
│   FirstItemRevision : Base revision number                              │
│   FirstItemIndex    : Start position in circular buffer                 │
│   ItemCount         : Total revisions in chain                          │
│   ChainLength       : Number of chunks                                  │
│   LastCommitRevision: For conflict detection                            │
│   AccessControlSmall: Thread-safe lock                                  │
├─────────────────────────────────────────────────────────────────────────┤
│                      CompRevStorageElement (10 bytes)                    │
├─────────────────────────────────────────────────────────────────────────┤
│   ComponentChunkId  : 32 bits (0 = deleted)                             │
│   TSN               : 48 bits (transaction sequence number)             │
│   IsolationFlag     : 1 bit (hides uncommitted)                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Circular Buffer Layout

```
Root Chunk (64 bytes):
  ┌────────────────────────────────────────────────────────────────────┐
  │ Header (58 bytes) │ Element[0] │ Element[1] │ ... │ Element[5]     │
  └────────────────────────────────────────────────────────────────────┘

Overflow Chunks (64 bytes each):
  ┌────────────────────────────────────────────────────────────────────┐
  │ NextPtr (4 bytes) │ Element[0] │ Element[1] │ ... │ Element[5]     │
  └────────────────────────────────────────────────────────────────────┘
```

### Revision Reading

```csharp
// Find visible revision for transaction
public bool TryGetRevision(long entityId, TSN snapshotTSN, out CompRevStorageElement revision)
{
    foreach (var rev in WalkRevisions(entityId))
    {
        // Skip uncommitted revisions from other transactions
        if (rev.IsolationFlag && rev.TSN != currentTransactionTSN)
            continue;

        // Find most recent revision visible to our snapshot
        if (rev.TSN <= snapshotTSN)
        {
            revision = rev;
            return rev.ComponentChunkId != 0;  // 0 = deleted
        }
    }
    return false;
}
```

### Code Location

`src/Typhon.Engine/Database Engine/ComponentRevision/`

---

## 4.6 B+Tree Indexes

### Purpose

Persistent B+Tree indexes for fast key-value lookups. Four variants optimized for different key sizes.

### Variants

| Variant | Key Size | Keys/Node | Use Cases |
|---------|----------|-----------|-----------|
| **L16BTree** | 16-bit | 8 | Byte, Short, UShort |
| **L32BTree** | 32-bit | 6 | Int, UInt, Float |
| **L64BTree** | 64-bit | 4 | Long, ULong, Double |
| **String64BTree** | 64-byte | 4 | String64 |

### Node Structure (64 bytes, cache-aligned)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        B+Tree Node (64 bytes)                            │
├─────────────────────────────────────────────────────────────────────────┤
│   Control (4 bytes)                                                      │
│     ├── Ownership bit (lock)                                            │
│     ├── StateFlags (15 bits)                                            │
│     ├── Start (8 bits) - circular buffer start                          │
│     └── Count (8 bits) - number of entries                              │
├─────────────────────────────────────────────────────────────────────────┤
│   PrevChunk (4 bytes) - doubly-linked sibling                           │
│   NextChunk (4 bytes) - doubly-linked sibling                           │
│   LeftValue (4 bytes) - leftmost child for internal nodes               │
├─────────────────────────────────────────────────────────────────────────┤
│   Keys[N] - sorted key array                                            │
│   Values[N] - parallel value array (chunk IDs or buffer refs)           │
└─────────────────────────────────────────────────────────────────────────┘
```

### Single vs Multiple

**Single-Value Index** (unique):
```csharp
[Index]  // One entity per key value
public int PlayerId;

// Storage: Key → ChunkId directly
```

**Multi-Value Index** (non-unique):
```csharp
[Index(AllowMultiple = true)]  // Multiple entities per key value
public float PositionX;

// Storage: Key → BufferRef → VariableSizedBuffer of ChunkIds
```

### Operations

```csharp
public interface IBTree<TKey>
{
    // Lookup
    bool TryGet(TKey key, out int value);

    // Iteration
    IEnumerable<(TKey Key, int Value)> Enumerate();

    // Modification (internal, called by Transaction)
    void Insert(TKey key, int value);
    void Remove(TKey key);
}
```

### Code Location

`src/Typhon.Engine/Database Engine/BPTree/`

---

## 4.7 Schema System

### Purpose

Runtime metadata for component definitions, fields, and indexes.

### Attributes

```csharp
// Mark struct as a database component
[Component("Game.Player", revision: 1, allowMultiple: false)]
public struct PlayerComponent
{
    // Mark field for storage
    [Field(fieldId: 1, name: "Health")]
    public float Health;

    // Mark field for indexing
    [Field(fieldId: 2, name: "AccountId")]
    [Index]
    public int AccountId;

    // Multi-value index (non-unique)
    [Field(fieldId: 3, name: "GuildId")]
    [Index(AllowMultiple = true)]
    public int GuildId;
}
```

### DBComponentDefinition

```csharp
public class DBComponentDefinition
{
    public string Name { get; }           // "Game.Player"
    public int Revision { get; }          // 1
    public bool AllowMultiple { get; }    // Can entity have multiple?

    public Dictionary<string, DBFieldDefinition> FieldsByName { get; }

    public int ComponentStorageSize { get; }      // sizeof(T)
    public int ComponentStorageTotalSize { get; } // + overhead
    public int IndicesCount { get; }
    public int MultipleIndicesCount { get; }
}
```

### Field Types

```csharp
public enum FieldType
{
    // Integers
    Boolean, Byte, Short, Int, Long,
    UByte, UShort, UInt, ULong,

    // Floats
    Float, Double,

    // Text
    Char, String64, String1024, String, Variant,

    // Vectors (2D/3D/4D, Float/Double)
    Point2F, Point2D, Point3F, Point3D, Point4F, Point4D,

    // Quaternions
    QuaternionF, QuaternionD,

    // Complex
    Collection, Component
}
```

### Code Location

`src/Typhon.Engine/Database Engine/Schema/`

---

## MVCC Deep Dive

### Read Path

```mermaid
sequenceDiagram
    participant TX as Transaction
    participant CT as ComponentTable
    participant PK as PrimaryKeyIndex
    participant REV as RevisionChain
    participant COMP as ComponentSegment

    TX->>CT: ReadEntity(entityId)
    CT->>PK: Lookup(entityId)
    PK-->>CT: RevChainFirstChunk

    CT->>REV: WalkRevisions(firstChunk)
    loop For each revision
        REV-->>CT: revision
        Note over CT: Skip if IsolationFlag && not my TX
        Note over CT: Stop if TSN ≤ my snapshot
    end

    CT->>COMP: GetChunk(revision.ComponentChunkId)
    COMP-->>TX: Component data
```

### Write Path

```mermaid
sequenceDiagram
    participant TX as Transaction
    participant CACHE as TX Cache
    participant CT as ComponentTable
    participant COMP as ComponentSegment
    participant REV as RevisionChain
    participant IDX as SecondaryIndexes

    TX->>CACHE: UpdateEntity(entityId, data)
    Note over CACHE: Store in local cache

    TX->>TX: Commit()

    loop For each cached change
        TX->>COMP: AllocateChunk()
        COMP-->>TX: newChunkId
        TX->>COMP: WriteData(newChunkId, data)

        TX->>REV: AddRevision(TSN, newChunkId)
        Note over REV: IsolationFlag cleared on commit

        TX->>IDX: UpdateIndexes(oldValue, newValue)
    end
```

### Conflict Resolution

```csharp
public enum ConcurrencyConflictResult
{
    Resolved,    // Handler merged changes, proceed
    Rollback,    // Abort the transaction
    Skip         // Skip this component, continue with others
}

public delegate ConcurrencyConflictResult ConcurrencyConflictHandler<T>(
    long entityId,
    ref T localValue,      // What we wanted to write
    ref T committedValue,  // What was committed by other TX
    ref T mergedValue      // Output: merged result
);
```

---

## Performance Characteristics

| Operation | Complexity | Notes |
|-----------|------------|-------|
| CreateEntity | O(log n) per index | B+Tree insertions |
| ReadEntity | O(log n) + O(k) | PK lookup + revision walk (k = chain length) |
| UpdateEntity | O(1) | Cached until commit |
| Commit | O(m log n) | m = modified entities, n = index size |
| Index Lookup | O(log n) | B+Tree search |

### Memory Efficiency

- **64-byte chunks**: Cache-line aligned for optimal access
- **Packed bit fields**: RevisionElement is 10 bytes (TSN + flags)
- **Transaction pooling**: Up to 16 reusable transaction objects
- **Zero-copy reads**: Components returned by reference where possible

---

## Current State

| Aspect | Status | Notes |
|--------|--------|-------|
| MVCC Transactions | ✅ Solid | Snapshot isolation, optimistic concurrency |
| B+Tree Indexes | ✅ Solid | All 4 variants, single + multi-value |
| Revision Chains | ✅ Solid | Circular buffer, garbage collection |
| Schema System | ✅ Solid | Attribute-based, runtime reflection |
| Conflict Handling | ✅ Solid | Default + custom handlers |
| Multi-Component | ⚠️ Known Issue | AllowMultiple cleanup has edge case |
| Schema Evolution | 🔮 Future | Version migration not implemented |

### Known Limitations

1. **AllowMultiple Cleanup**: When cleaning up deleted AllowMultiple components, entries remain in primary key index (marked as deleted). Workaround exists but proper cleanup needs implementation.

2. **TSN Rollover**: At 1M transactions/second, TSN exhausts in ~8,900 years. Warning logged at 1 << 46 but no rollover logic.

3. **Schema Loading**: Database file loading stub exists but not fully implemented.

---

## Design Decisions

| Question | Decision | Rationale |
|----------|----------|-----------|
| **Concurrency model** | Optimistic MVCC | High read throughput, no reader blocking |
| **Chunk size** | 64 bytes | Cache-line aligned, fits B+Tree node |
| **Revision storage** | Circular buffer | Efficient GC, bounded memory per entity |
| **Index variants** | 4 sizes (16/32/64/String64) | Optimize storage per key type |
| **Transaction pooling** | Max 16 | Balance memory vs allocation overhead |
| **Conflict default** | Last write wins | Simple, predictable; custom available |
