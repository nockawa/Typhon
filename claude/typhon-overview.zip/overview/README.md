# Typhon Architecture Overview

This directory provides a **complete architectural overview** of the Typhon database engine - from high-level components down to implementation details.

---

## What is Typhon?

**Typhon** is an embedded, real-time ACID database engine with microsecond-level performance targets. It combines:

- **Entity-Component-System (ECS) data model** - Entities are just IDs; data lives in typed, blittable component structs
- **MVCC concurrency** - Snapshot isolation with optimistic conflict detection, readers never block writers
- **Persistent B+Tree indexes** - Automatic secondary indexes on component fields
- **Memory-mapped storage** - Clock-sweep page cache with configurable durability

### Who is it for?

Typhon is designed for workloads that need:

| Workload | Why Typhon Fits |
|----------|-----------------|
| **Game servers** | High-frequency updates (100K+ ops/sec), ECS-native model, transactional safety for player state |
| **Simulations** | MVCC allows concurrent reads during world updates, incremental view maintenance |
| **Real-time systems** | Microsecond reads, predictable latency, no GC pressure from data storage |
| **Embedded applications** | No separate server, runs in-process, single-file storage |

### What it's NOT

- Not a general-purpose SQL database (no joins in the traditional sense - uses entity references)
- Not designed for cloud/distributed deployments (single-node embedded)
- Not optimized for analytical/OLAP workloads (focuses on OLTP patterns)

---

## Typhon 101: Quick Start

### Define a Component

```csharp
[Component]
public struct PlayerComponent
{
    [Field]
    public String64 Name;      // Fixed-size string (max 64 bytes)

    [Field]
    [Index]                    // Creates B+Tree for fast lookups
    public int AccountId;

    [Field]
    public float Experience;
}
```

**Key rules**: Components must be unmanaged structs (no strings, arrays, or class references). Use `String64` for short text.

### Basic Operations

```csharp
// Setup (once at startup)
using var dbe = serviceProvider.GetRequiredService<DatabaseEngine>();
dbe.RegisterComponent<PlayerComponent>();

// Create
using (var t = dbe.CreateTransaction())
{
    var player = new PlayerComponent { Name = "Alice", AccountId = 123, Experience = 0 };
    long entityId = t.CreateEntity(ref player);
    t.Commit();
}

// Read
using (var t = dbe.CreateTransaction())
{
    if (t.ReadEntity(entityId, out PlayerComponent player))
        Console.WriteLine($"Player: {player.Name}, XP: {player.Experience}");
}

// Update
using (var t = dbe.CreateTransaction())
{
    if (t.ReadEntity(entityId, out PlayerComponent player))
    {
        player.Experience += 100;
        t.UpdateEntity(entityId, player);
        t.Commit();
    }
}

// Query by index
using (var t = dbe.CreateTransaction())
{
    var index = t.GetIndex<PlayerComponent, int>(nameof(PlayerComponent.AccountId));
    foreach (var id in index.Get(123))
    {
        t.ReadEntity(id, out PlayerComponent p);
        Console.WriteLine($"Found: {p.Name}");
    }
}
```

### Multi-Component Entities

An entity can have multiple component types attached:

```csharp
// Entity 42 has both PlayerComponent and InventoryComponent
t.CreateEntity(ref player);           // Returns entityId = 42
t.CreateComponent(42, ref inventory); // Attach another component
t.CreateComponent(42, ref health);    // And another
t.Commit();

// Read any component by entity ID
t.ReadEntity(42, out PlayerComponent p);
t.ReadEntity(42, out InventoryComponent i);
```

### Transaction Guarantees

- **Atomicity** - All changes in a transaction succeed or all fail
- **Isolation** - Snapshot isolation; you see a consistent view from transaction start
- **Durability** - Configurable per-component (some games prefer speed over crash safety)
- **Conflict Resolution** - Default "last write wins", or provide custom merge logic

---

## Current Capabilities vs. Roadmap

### What Works Today

| Feature | Status | Notes |
|---------|--------|-------|
| Component CRUD | ✅ Solid | Create, Read, Update, Delete within transactions |
| MVCC Transactions | ✅ Solid | Snapshot isolation, optimistic concurrency, conflict detection |
| B+Tree Indexes | ✅ Solid | L16/L32/L64/String64 variants, single & multi-value |
| Page Cache | ✅ Solid | Memory-mapped files, clock-sweep eviction, 8KB pages |
| Secondary Indexes | ✅ Solid | Automatic index maintenance on marked fields |
| Multi-Component Entities | ✅ Solid | Same entity ID across multiple component tables |
| Transaction Pooling | ✅ Solid | Reuse transaction objects to reduce allocations |

### In Progress / Designed

| Feature | Status | Notes |
|---------|--------|-------|
| Query Engine | 📐 Designed | WHERE clauses, Views, incremental maintenance - [design ready](../design/QueryEngine.md) |
| Telemetry | 🔧 In Progress | Contention tracking, page I/O metrics, configurable |
| AccessControl Refactor | 🔧 In Progress | Timeout/deadline support, better telemetry |

### Planned (Not Yet Started)

| Feature | Priority | Notes |
|---------|----------|-------|
| WAL / Durability | High | Write-ahead log for crash recovery |
| Crash Recovery | High | Restore consistent state after failure |
| Checkpointing | High | Periodic consistent snapshots |
| Backup & Restore | Medium | Incremental page-based backups |
| Resource Budgets | Medium | Memory limits, fail-fast on exhaustion |

---

## Purpose

When working on Typhon, it's easy to lose sight of the forest for the trees. This overview serves as:

1. **Navigation Map** - Understand where each piece fits in the larger architecture
2. **Design Reference** - Capture key decisions and their rationale
3. **Onboarding Guide** - Get up to speed on the system's structure
4. **Planning Tool** - Identify gaps, dependencies, and implementation priorities

## How to Use

Start with the **Main Components** below for the big picture, then drill into specific areas as needed. Each component document follows a consistent structure: purpose, sub-components, current state, and key design decisions.

---

## Main Components (Level 0)

Typhon is organized into **11 main components**, each with distinct responsibilities:

| # | Component | Description | Status |
|---|-----------|-------------|--------|
| **1** | [Concurrency & Synchronization](./01-concurrency.md) | Latches, locks, deadlines, cancellation, wait infrastructure | Mixed |
| **2** | [Execution System](./02-execution.md) | Internal work items, scheduling, transaction deadlines | New |
| **3** | [Storage Engine](./03-storage.md) | Page management, buffer pool, segments, disk I/O | Exists |
| **4** | [Data Engine](./04-data.md) | Schema, ComponentTable, B+Trees, MVCC, transactions | Exists |
| **5** | [Query Engine](./05-query.md) | Query parsing, filtering (WHERE), sorting, limits | New |
| **6** | [Durability & Recovery](./06-durability.md) | WAL/journal, crash recovery, checkpointing | New |
| **7** | [Backup & Restore](./07-backup.md) | Page-based incremental backup, point-in-time reconciliation | New |
| **8** | [Observability](./08-observability.md) | OpenTelemetry traces/metrics, health checks, diagnostics | Partial |
| **9** | [Resource Management](./09-resources.md) | Memory budgets, page cache limits, fail-fast | Partial |
| **10** | [Error Handling & Resilience](./10-errors.md) | Consistent error model, exception hierarchy | Scattered |
| **11** | [Shared Utilities](./11-utilities.md) | Catalog manager, memory allocators, disk management | Partial |

### Status Legend

- **Exists** - Core functionality implemented, may need hardening
- **Partial** - Some pieces exist, others missing
- **Mixed** - Sub-components vary significantly in maturity
- **New** - Not yet implemented
- **Scattered** - Exists but not cohesively organized

---

## Architecture Principles

These principles guide Typhon's design:

1. **Microsecond Performance** - Every memory access counts; minimize cache misses, maximize data locality
2. **ACID with Flexibility** - Full transaction support, but durability is configurable per-component
3. **ECS-Inspired Model** - Entities are just IDs; components are blittable structs
4. **MVCC for Concurrency** - Snapshot isolation via multi-version concurrency control
5. **Embedded First** - No separate server process; runs in-process with the application

---

## Dependency Flow

Components have natural dependencies on each other:

```mermaid
flowchart TB
    subgraph Application
        APP[Application Layer]
    end

    subgraph Core["Core Engine"]
        QUERY[5. Query Engine]
        DATA[4. Data Engine<br/>Schema, Tables, B+Trees, Transactions]
    end

    subgraph Infrastructure
        DURABLE[6. Durability<br/>WAL, Recovery]
        STORAGE[3. Storage Engine<br/>Pages, Buffer Pool]
        EXEC[2. Execution System<br/>Work Items, Scheduling]
    end

    subgraph Foundation
        CONCURRENCY[1. Concurrency & Synchronization<br/>Latches, Deadlines, Cancellation]
        UTILS[11. Shared Utilities<br/>Allocators, String64, Variant]
    end

    subgraph CrossCutting["Cross-Cutting Concerns"]
        BACKUP[7. Backup & Restore]
        OBSERVE[8. Observability]
        RESOURCE[9. Resource Management]
        ERRORS[10. Error Handling]
    end

    APP --> QUERY
    QUERY --> DATA
    DATA --> DURABLE
    DATA --> STORAGE
    DATA --> EXEC
    DURABLE --> CONCURRENCY
    STORAGE --> CONCURRENCY
    EXEC --> CONCURRENCY
    CONCURRENCY --> UTILS

    CrossCutting -.-> Core
    CrossCutting -.-> Infrastructure
    CrossCutting -.-> Foundation
```

The vertical flow shows the primary dependency chain. Cross-cutting concerns (7-10) integrate throughout all layers via dotted lines.

---

## Current Codebase Mapping

| Component | Primary Location in Code |
|-----------|-------------------------|
| 1. Concurrency | `src/Typhon.Engine/Misc/AccessControl/`, `Misc/AdaptiveWaiter.cs` |
| 2. Execution | *(to be created)* |
| 3. Storage | `src/Typhon.Engine/Persistence Layer/` |
| 4. Data | `src/Typhon.Engine/Database Engine/` |
| 5. Query | *(to be created)* |
| 6. Durability | *(to be created)* |
| 7. Backup | *(to be created)* |
| 8. Observability | `src/Typhon.Engine/Telemetry/` |
| 9. Resources | `src/Typhon.Engine/Misc/Resource Registry/`, `Misc/MemoryAllocator/` |
| 10. Errors | *(scattered, needs consolidation)* |
| 11. Utilities | `src/Typhon.Engine/Misc/`, `Collections/` |

---

## Next Steps

Each component document (linked above) will be created as we drill down. Priority order for documentation:

1. **Concurrency** - Foundation everything depends on
2. **Storage Engine** - Core persistence, already exists
3. **Data Engine** - Core database logic, already exists
4. **Execution System** - Needed for timeouts and background work
5. **Durability** - The "D" in ACID
6. *Others as needed...*
