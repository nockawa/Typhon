# Component 7: Backup & Restore

> Page-based incremental backup and point-in-time restore capabilities.

---

## Overview

The Backup component provides mechanisms to create and restore database backups, leveraging the page-based storage model for efficient incremental backups.

```mermaid
flowchart TB
    subgraph Application
        ADMIN[Admin Operations]
    end

    subgraph Backup["Backup & Restore"]
        FULL[Full Backup<br/>All pages]
        INCR[Incremental Backup<br/>Changed pages only]
        RESTORE[Restore Manager<br/>Apply backups]
    end

    subgraph Storage["Storage Engine"]
        MMF[ManagedPagedMMF]
        CHANGES[ChangeSet<br/>Modified pages]
    end

    subgraph External["External Storage"]
        DISK[Backup Files]
        CLOUD[Cloud Storage]
    end

    ADMIN --> FULL
    ADMIN --> INCR
    ADMIN --> RESTORE
    FULL --> MMF
    INCR --> CHANGES
    FULL --> DISK
    INCR --> DISK
    RESTORE --> DISK
    RESTORE --> MMF
    DISK --> CLOUD
```

---

## Status: 🆕 New

This component does not yet exist in the codebase. This document captures the design requirements.

---

## Sub-Components

| # | Name | Purpose | Status |
|---|------|---------|--------|
| **7.1** | [Full Backup](#71-full-backup) | Complete database snapshot | 🆕 New |
| **7.2** | [Incremental Backup](#72-incremental-backup) | Changed pages since last backup | 🆕 New |
| **7.3** | [Restore Manager](#73-restore-manager) | Apply backups to restore database | 🆕 New |

---

## 7.1 Full Backup

### Purpose

Create a complete snapshot of the database at a consistent point in time.

### Design Sketch

```csharp
public interface IBackupManager
{
    // Create full backup
    Task<BackupInfo> CreateFullBackupAsync(
        string destinationPath,
        IProgress<BackupProgress> progress = null,
        CancellationToken token = default);

    // List available backups
    IEnumerable<BackupInfo> ListBackups(string backupDirectory);
}

public record BackupInfo
{
    public BackupType Type { get; init; }        // Full or Incremental
    public DateTime Timestamp { get; init; }
    public long SizeBytes { get; init; }
    public int PageCount { get; init; }
    public string FilePath { get; init; }
    public long BaseLSN { get; init; }           // For chaining incrementals
}
```

### Backup File Format

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Backup File Format                                │
├─────────────────────────────────────────────────────────────────────────┤
│   Header (256 bytes)                                                     │
│     Magic: "TYPHONBK"                                                   │
│     Version: 1                                                          │
│     Type: Full/Incremental                                              │
│     Timestamp: UTC                                                      │
│     PageCount: N                                                        │
│     BaseLSN: for incremental chain                                      │
│     Checksum: CRC32 of header                                           │
├─────────────────────────────────────────────────────────────────────────┤
│   Page Index (N × 12 bytes)                                             │
│     [PageIndex: 4, Offset: 8]                                           │
├─────────────────────────────────────────────────────────────────────────┤
│   Page Data (N × 8192 bytes, compressed)                                │
├─────────────────────────────────────────────────────────────────────────┤
│   Footer                                                                 │
│     Checksum: CRC32 of entire file                                      │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 7.2 Incremental Backup

### Purpose

Capture only pages that changed since the last backup, reducing backup size and time.

### Change Tracking

Leverage the Storage Engine's ChangeRevision counter:

```csharp
// Each page has a change revision
public struct PageBaseHeader
{
    public long ChangeRevision;  // Incremented on every write
}

// Incremental backup captures pages where:
// page.ChangeRevision > lastBackupRevision
```

### Design Sketch

```csharp
public interface IBackupManager
{
    // Create incremental backup based on previous
    Task<BackupInfo> CreateIncrementalBackupAsync(
        BackupInfo baseBackup,
        string destinationPath,
        IProgress<BackupProgress> progress = null,
        CancellationToken token = default);
}
```

### Incremental Chain

```
Full Backup (Day 1)
    └── Incremental 1 (Day 2)
        └── Incremental 2 (Day 3)
            └── Incremental 3 (Day 4)

Restore Day 4 = Apply Full + Incr1 + Incr2 + Incr3
```

---

## 7.3 Restore Manager

### Purpose

Apply backup files to restore a database to a specific point in time.

### Design Sketch

```csharp
public interface IRestoreManager
{
    // Restore from backup
    Task RestoreAsync(
        string backupPath,
        string destinationPath,
        RestoreOptions options = null,
        CancellationToken token = default);

    // Validate backup integrity
    Task<bool> ValidateBackupAsync(string backupPath);
}

public class RestoreOptions
{
    // Restore to specific point-in-time (requires WAL)
    public DateTime? PointInTime { get; set; }

    // Overwrite existing database
    public bool Overwrite { get; set; } = false;

    // Verify pages after restore
    public bool VerifyAfterRestore { get; set; } = true;
}
```

---

## Compression

Backups support optional compression:

| Algorithm | Ratio | Speed | Use Case |
|-----------|-------|-------|----------|
| **None** | 1:1 | Fastest | Fast local backups |
| **LZ4** | ~2:1 | Fast | Default, good balance |
| **Zstd** | ~3:1 | Moderate | Long-term storage |

---

## Integration with Durability

### Consistent Backups

Full backups must be taken at a consistent point:

```mermaid
sequenceDiagram
    participant BM as Backup Manager
    participant CM as Checkpoint Manager
    participant MMF as ManagedPagedMMF

    BM->>CM: Request consistent point
    CM->>CM: Quiesce new transactions
    CM->>MMF: Flush dirty pages
    CM-->>BM: CheckpointLSN

    BM->>MMF: Copy all pages
    BM->>BM: Record CheckpointLSN in backup

    CM->>CM: Resume transactions
```

### Point-in-Time Recovery

With WAL integration, restore to specific timestamp:

```
1. Restore most recent full backup before target time
2. Apply incrementals up to target time
3. Replay WAL from backup LSN to target LSN
4. Undo uncommitted transactions at target time
```

---

## Code Locations (Planned)

| Component | Planned Location |
|-----------|------------------|
| Backup Manager | `src/Typhon.Engine/Backup/BackupManager.cs` |
| Restore Manager | `src/Typhon.Engine/Backup/RestoreManager.cs` |
| Backup Format | `src/Typhon.Engine/Backup/BackupFormat.cs` |

---

## Design Decisions

| Question | Decision | Rationale |
|----------|----------|-----------|
| **Backup unit** | Page-level | Matches storage model, efficient |
| **Compression** | LZ4 default | Good speed/ratio balance |
| **Incremental chain** | Unlimited depth | Flexibility, can compact later |
| **Consistency** | Checkpoint-based | Leverage existing mechanism |

---

## Open Questions

1. **Retention policy?** - How long to keep old backups? Auto-cleanup?

2. **Cloud integration?** - Should we support direct upload to S3/Azure/GCS?

3. **Encryption?** - Should backups be encrypted at rest?
